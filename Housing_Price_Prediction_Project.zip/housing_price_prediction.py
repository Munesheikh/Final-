# Housing Price Prediction using Machine Learning
# Task 3 - ARCH Technologies Internship
# Author: Muneeba Shakir

import numpy as np
import pandas as pd
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load the dataset
housing = fetch_california_housing(as_frame=True)
X = housing.data
y = housing.target

print("Dataset Shape:", X.shape)
print("First 5 rows:\n", X.head())

# Step 2: Preprocessing - Scaling features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 3: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Step 4: Train the model (Linear Regression)
model = LinearRegression()
model.fit(X_train, y_train)

# Step 5: Predictions
y_pred = model.predict(X_test)

# Step 6: Evaluation
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print("\nModel Performance:")
print("Root Mean Squared Error (RMSE):", rmse)
print("R^2 Score:", r2)
