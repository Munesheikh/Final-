Housing Price Prediction - Machine Learning Task 3
-------------------------------------------------

This project uses the California Housing dataset to predict 
house prices based on features such as location, number of rooms, 
and population.

Steps in the code:
1. Load dataset (from sklearn.datasets)
2. Preprocess features using StandardScaler
3. Split data into training (80%) and testing (20%)
4. Train Linear Regression model
5. Evaluate model using RMSE and R^2 score

How to Run:
-----------
1. Install required libraries:
   pip install -r requirements.txt

2. Run the Python script:
   python housing_price_prediction.py

Expected Output:
----------------
- Dataset shape and first 5 rows
- Model Performance with RMSE and R^2 Score

Author: Muneeba Shakir
