Iris Flower Classification - Machine Learning Task 4
----------------------------------------------------

This project uses the famous Iris dataset to classify flowers into
three species (Setosa, Versicolor, Virginica) based on sepal length, 
sepal width, petal length, and petal width.

Steps in the code:
1. Load dataset (from sklearn.datasets)
2. Preprocess features using StandardScaler
3. Split data into training (80%) and testing (20%)
4. Train Logistic Regression model
5. Evaluate model accuracy and print results

How to Run:
-----------
1. Install required libraries:
   pip install -r requirements.txt

2. Run the Python script:
   python iris_classification.py

Expected Output:
----------------
- First 5 rows of dataset
- Model Accuracy (around 96-100%)
- Confusion Matrix
- Classification Report

Author: Muneeba Shakir
